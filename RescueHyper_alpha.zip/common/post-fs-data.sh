#!/system/bin/sh

# 定义音量键设备文件路径
VOLUME_UP_DEV="/dev/input/event0"
VOLUME_DOWN_DEV="/dev/input/event3"

# 获取脚本所在的目录
MODDIR=${0%/*}
modulesParent=$(dirname $MODDIR)

# 定义日志文件路径
LOG_FILE="$MODDIR/log.txt"
BOOT_FAILURE_FILE="$MODDIR/boot_failure_count.txt"

# 定义带时间戳的日志输出函数
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

# 检测音量键事件的通用函数
detect_volume_event() {
    local device=$1
    local key_pattern=$2
    local count_var=$3
    local threshold=$4
    local action_func=$5

    events=$(timeout 1 getevent -qlc 1 $device 2>/dev/null)
    for event in $events; do
        if echo "$event" | grep -q "$key_pattern"; then
            eval "$count_var=\$((\$count_var + 1))"
            if [ $(eval echo \$$count_var) -ge $threshold ]; then
                $action_func
                return 0
            fi
        fi
    done
    return 1
}

# 定义禁用除自身外的所有Magisk模块的函数
disable_other_modules() {
    for path in $(ls $modulesParent); do
        if [ "$path" != "$(basename $MODDIR)" ]; then
            touch "$modulesParent/$path/disable"
        fi
    done
    log "已禁用除自身外的所有Magisk模块"
}

# 定义修改setting.txt文件中恢复标识的函数
change_restore_flag() {
    setting_file="$MODDIR/setting.txt"
    if [ -f "$setting_file" ]; then
        sed -i 's/^Recovery=.*/Recovery=1/' "$setting_file"
        log "已将setting.txt文件中恢复标识修改为1"
    fi
}

# 定义处理启动失败的函数
handle_boot_failure() {
    rm -rf /data/system/users/0/package-restrictions.xml
    settings delete secure enabled_accessibility_services
    rm -rf /data/dalvik-cache/*
    log "已解冻恢复软件、禁用无障碍功能并清除虚拟机缓存"
}

# 读取系统启动失败次数
boot_failure_count=$(cat "$BOOT_FAILURE_FILE" 2>/dev/null || echo 0)

# 判断系统是否正常启动
if [[ $(getprop init.svc.bootanim) != "stopped" ]]; then
    boot_failure_count=$((boot_failure_count + 1))
    echo "$boot_failure_count" > "$BOOT_FAILURE_FILE"
    log "系统启动失败，当前失败次数：$boot_failure_count"
    if [ $boot_failure_count -ge 2 ]; then
        handle_boot_failure
    fi
else
    echo "0" > "$BOOT_FAILURE_FILE"
fi

sleep 1
echo "请在10秒内按下音量键+或音量键-"
log "请在10秒内按下音量键+或音量键-"

# 等待10秒并检测音量键事件
end_time=$(($(date +%s) + 10))
count_up=0
count_down=0
while [ $(date +%s) -lt $end_time ]; do
    detect_volume_event $VOLUME_UP_DEV "KEY_VOLUMEUP" count_up 3 disable_other_modules && break
    detect_volume_event $VOLUME_DOWN_DEV "KEY_VOLUMEDOWN" count_down 2 change_restore_flag && break
    sleep 0.1
done

# 如果10秒后没有达到触发条件，输出提示信息
if [ $count_up -lt 3 ] && [ $count_down -lt 2 ]; then
    echo "10秒内未达到触发条件"
    log "10秒内未达到触发条件"
fi
