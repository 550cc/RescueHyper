#!/system/bin/sh
source "functions"

MODDIR=${0%/*}
log_file="${MODDIR}/start.log"
settings_file="${MODDIR}/setting.txt"
magisk_module_prop="${MODDIR}/module.prop"
count_file="${MODDIR}/count.txt"


# 记录日志
log() {
    echo "$1" >> "$log_file"
}



# 主函数
main() {
    check_recovery  
    clean_log
    initialize_log
    parse_settings
    set_defaults
    log_execution_time
    delay_execution

    local plugin_dir=$(get_plugin_dir)

    check_md5_match "$plugin_dir"

    case "$install_mode" in
        A)
            install_apk_if_needed_A "$plugin_dir"
            ;;
        B)
            install_apk_if_needed_B "$plugin_dir"
            ;;
        *)
            log "未知的安装模式：$install_mode"
            exit 1
            ;;
    esac


    # 重启应用
    if [ "$restart_systemui" = "true" ]; then
        restart_app com.miui.systemui.plugin
    fi

    update_description
    clean_log
    exit 0
}

# 调用主函数
main
