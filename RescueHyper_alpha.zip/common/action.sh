#!/system/bin/sh
source $(dirname $0)/functions

MODDIR=${0%/*}
log_file="${MODDIR}/action.log"
settings_file="${MODDIR}/setting.txt"
magisk_module_prop="${MODDIR}/module.prop"
count_file="${MODDIR}/count.txt"

# 检查模块状态
module_status() {
    if grep -q "disable=1" "$magisk_module_prop"; then
        sed -i '/disable=1/d' "$magisk_module_prop"
        echo "模块已启用" >> "$log_file"
    else
        echo "模块已处于启用状态" >> "$log_file"
    fi
}

# 安装软件
install_software() {
    install_mode=$(grep '^install_mode=' "$settings_file" | cut -d'=' -f2)
    case "$install_mode" in
        A)
            original_apk="/product/app/MIUISystemUIPlugin/MIUISystemUIPlugin.apk"
            install_apk "$original_apk"
            ;;
        B)
            base_apk="${MODDIR}/app/base.apk"
            install_apk "$base_apk"
            ;;
        *)
            echo "未知的安装模式：$install_mode" >> "$log_file"
            exit 1
            ;;
    esac
}

# 初始化日志文件
initialize_log() {
    echo "脚本开始执行：$(date '+%Y年%m月%d日%H:%M:%S')" >> "$log_file"
}


# 更新模块描述文件
update_description() {
    local version=$(get_miui_systemui_plugin_version)
    local current_count=$(cat "$count_file" | cut -d'=' -f2)
    local description="重启后自动安装原版app并禁用自身，模块状态：[Action脚本已执行]，救砖模式[$install_mode]，系统组件版本[$version]，安装后重启组件[$restart_systemui]，已触发次数[$current_count]"
    sed -i "s/^description=.*/description=$description/" "$magisk_module_prop"
}

# 主函数
main() {
    # 初始化日志文件
    initialize_log

    # 解析设置文件并设置默认值
    parse_settings
    set_defaults

    # 检查模块状态
    module_status

    # 延迟执行
    delay_execution

    # 安装软件
    install_software

    # 更新模块描述文件
    update_description

    # 清理日志文件
    clean_log

    # 记录脚本执行时间
    log_execution_time

    exit 0
}

# 调用主函数
main
